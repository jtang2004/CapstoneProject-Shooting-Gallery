import java.awt.Color;

public interface Target {
public int targetSize();
public Color targetColor();
public int pointValue();
}
