import java.awt.Color;
import java.util.Random;

public class BasicTarget implements Target {
	Random rand= new Random();

	
	public int targetSize() {
		// TODO Auto-generated method stub
		return 50;
	}

	
	public Color targetColor() {
		// TODO Auto-generated method stub
		return Color.RED;
	}

	
	public int pointValue() {
		// TODO Auto-generated method stub
		return 100;
	} 
	public int xLocation() {
		return rand.nextInt(1900);
		
	}
	public int yLocation() {
		return rand.nextInt(1060);
		
	}

}
