import java.awt.Color;

import java.awt.Graphics;
import java.awt.Rectangle;

import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.event.*;

public class Gallery extends JPanel implements MouseListener,MouseMotionListener,ActionListener{
	private JButton StartButton;
int x,y;
boolean motion=false;
	public Gallery() {
		super();
		addMouseListener(this);
		addMouseMotionListener(this);
	}

	  


	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		e.getX();
		e.getY();
		
		
	}
	public void paintComponent(Graphics g) {
	super.paintComponent(g);
	BasicTarget z= new BasicTarget();
	
	
	if(motion) {
	g.setColor(Color.CYAN);
	g.drawOval(x-10,y-10,20,20);
	g.drawLine (x,y-10,x,y+10);
	g.drawLine (x-10,y,x+10,y);
	}
	for(int i=0; i<3;i++) {
		g.fillOval(z.xLocation(), z.yLocation(), z.targetSize(),z.targetSize());
	}
	
	
	}

	
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub 
		
	}

	
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	
	}

	
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		  

	  }



	
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		  x = e.getX();
		  y = e.getY();
		  motion=true;
		
			
		  

		  repaint();
	
		    
	}




	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}




	


}
