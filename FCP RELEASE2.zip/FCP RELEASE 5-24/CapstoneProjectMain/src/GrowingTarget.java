import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

public class GrowingTarget extends JPanel implements Target, ActionListener {
	private int xLocation;
	private int yLocation;
	boolean grow = true;
	private int size;
	private int pointValue;
	Random rand = new Random();
	private Image growingTarget = new ImageIcon("GrowingTarget.png").getImage();

	public GrowingTarget() {
		xLocation = 400;
		yLocation = 400;
		size = 5;
		pointValue = 150;
		Timer clock = new Timer(300, this);
		clock.start();
	}

	public void setLocation() {
		// TODO Auto-generated method stub
		size = 5;
		xLocation = rand.nextInt(800 - size);
		yLocation = rand.nextInt(600 - size);

	}

	@Override
	public void draw(Graphics g) {
		// TODO Auto-generated method stub
		g.drawImage(growingTarget, xLocation, yLocation, size, size, this);
	}

	@Override
	public int getTargetSize() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public int getPointValue() {
		// TODO Auto-generated method stub
		return pointValue;
	}

	@Override
	public int getXLocation() {
		// TODO Auto-generated method stub
		return xLocation;
	}

	@Override
	public int getYLocation() {
		// TODO Auto-generated method stub
		return yLocation;
	}

	public void grow() {
		if (grow) {
			size += 5;
		}
		if (size > 100) {
			grow = false;

		}
		if (grow == false) {
			size -= 5;
		}
		if (size == 0) {
			setLocation();

			grow = true;
		}

	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		grow();
		repaint();
	}

}
