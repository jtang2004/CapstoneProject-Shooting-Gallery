import java.awt.Graphics;

import java.awt.Image;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class EvilTarget extends JPanel implements Target{

	private int xLocation;
	private int yLocation;

	private int size;
	private int pointValue;
	Random rand = new Random();
	private Image evilTarget = new ImageIcon("evilTarget.png").getImage();
	private Image explosion = new ImageIcon("explosion.png").getImage();
	public EvilTarget() {
		xLocation = rand.nextInt(750);
		yLocation = rand.nextInt(550);
		size = 50;
		pointValue = -5;
	}
	public void setLocation() {
		// TODO Auto-generated method stub
	}

	@Override
	public void draw(Graphics g) {
		// TODO Auto-generated method stub
		g.drawImage(evilTarget, xLocation,yLocation,this);
	}

	@Override
	public int getTargetSize() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public int getPointValue() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getXLocation() {
		// TODO Auto-generated method stub
		return xLocation;
	}

	@Override
	public int getYLocation() {
		// TODO Auto-generated method stub
		return yLocation;
	}
	public void explode(Graphics g) {
		g.drawImage(explosion,xLocation,yLocation,this);
	}
}
