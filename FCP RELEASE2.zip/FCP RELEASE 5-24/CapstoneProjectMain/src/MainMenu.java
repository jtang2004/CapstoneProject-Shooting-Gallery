import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainMenu extends JPanel implements ActionListener, MouseListener{
	public static String button;
	//public static JButton button;
	//private JButton start = new JButton("Press to Play");
	private int times = 0;

	public MainMenu() {

		super();
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		times++;
		System.out.print("done");
		repaint();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String action = e.getActionCommand();
		if("Press to Play".equals(action)) {
		//if(times>=1) {
			JFrame info = new JFrame("Main Menu");
			info.setBounds(0, 0, 800, 600);    
			info.getContentPane().setBackground(Color.WHITE); 
			info.setResizable(false); 
			Gallery panel = new Gallery();
			info.add(panel);
			panel.setBackground(Color.WHITE);
			info.setVisible(true);
		}

		repaint();
	}
}
