import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.io.File;
import java.io.InputStream;

public class ShootingGallery {

	public static void main(String[] args) {
		
		
		MainMenu.button = JOptionPane.showInputDialog("Enter 'start' to play");
		
		JFrame ShootingGallery = new JFrame("Shooting Gallery");
		ShootingGallery.setBounds(0, 0, 800, 600);
		ShootingGallery.getContentPane().setBackground(Color.WHITE);
		ShootingGallery.setResizable(false);
		ShootingGallery.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Gallery panel = new Gallery();
		ShootingGallery.add(panel);
		panel.setBackground(Color.WHITE);
		ShootingGallery.setVisible(true);
		playCrystals(true);
		
		

	}

	public static void playCrystals(boolean x) {

		try {

			File file = new File("Crystals.wav");
			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(file));
			if (x) {
				clip.start();
			} else {
				clip.stop();
			}
			Thread.sleep(clip.getMicrosecondLength());
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
}
